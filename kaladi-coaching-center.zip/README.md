# Kaladi Coaching Center

A modern, full-stack application for managing Kaladi Coaching Center, students, and academic records.

## Features

- **Role-Based Access Control**:
  - **Admin**: Full control over students, attendance, and announcements.
  - **Teacher**: Can mark attendance, upload results, and post announcements.
  - **Student**: View personalized dashboard, attendance logs, and test results.
- **Attendance Tracking**: Real-time attendance logging with visual summaries.
- **Academic Management**: Track test results, upcoming tests, and assignments.
- **Announcements**: Real-time notification system for academy-wide updates.
- **Modern UI**: Responsive design built with Tailwind CSS and Framer Motion.

## Tech Stack

- **Frontend**: React, Vite, Tailwind CSS, Lucide React, Recharts, Motion.
- **Backend**: Node.js, Express, JWT, Bcrypt.
- **Database**: In-memory store (for demo purposes).

## Getting Started

1. **Install Dependencies**:
   ```bash
   npm install
   ```
2. **Start Development Server**:
   ```bash
   npm run dev
   ```
3. **Login with Demo Accounts**:
   - **Admin**: `shahzadalilund@gmail.com` / `Kcc2606`
   - **Teacher**: `teacher@academy.com` / `password123`
   - **Student**: `student@academy.com` / `password123`

## Usage

- **Dashboard**: View key metrics like attendance rate and performance trends.
- **Attendance**: Select a student (as Admin/Teacher) to mark or view their attendance logs.
- **Academic**: View upcoming tests and published results.
- **Students**: Manage the student directory (Admin/Teacher only).
- **Announcements**: Post and view academy-wide updates.
