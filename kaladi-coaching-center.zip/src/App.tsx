import React, { useState, useEffect, createContext, useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Users, 
  Calendar, 
  ClipboardList, 
  Bell, 
  LayoutDashboard, 
  LogOut, 
  Menu, 
  X, 
  Plus, 
  Search,
  CheckCircle2,
  XCircle,
  TrendingUp,
  GraduationCap,
  BookOpen,
  Trash2,
  User as UserIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, parseISO } from 'date-fns';

import { User, Role, Attendance, Test, Result, Announcement, AuthState } from './types';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Context ---
const AuthContext = createContext<{
  state: AuthState;
  login: (token: string, user: User) => void;
  logout: () => void;
} | null>(null);

const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

// --- API Helpers ---
const api = {
  async get(url: string, token: string | null) {
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('API Error');
    return res.json();
  },
  async post(url: string, data: any, token: string | null) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('API Error');
    return res.json();
  },
  async delete(url: string, token: string | null) {
    const res = await fetch(url, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('API Error');
    return res.status === 204 ? null : res.json();
  }
};

// --- Components ---

const Sidebar = ({ isOpen, toggle }: { isOpen: boolean; toggle: () => void }) => {
  const { state, logout } = useAuth();
  const location = useLocation();

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Attendance', path: '/attendance', icon: Calendar },
    { name: 'Tests & Results', path: '/academic', icon: ClipboardList },
    { name: 'Announcements', path: '/announcements', icon: Bell },
  ];

  if (state.user?.role === 'admin' || state.user?.role === 'teacher') {
    navItems.push({ name: 'Students', path: '/students', icon: Users });
  }

  return (
    <>
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          <div className="p-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
              <GraduationCap className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight">Kaladi Coaching Center</span>
          </div>

          <nav className="flex-1 px-4 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => toggle()}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
                  location.pathname === item.path 
                    ? "bg-indigo-600 text-white" 
                    : "text-slate-400 hover:bg-slate-800 hover:text-white"
                )}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.name}</span>
              </Link>
            ))}
          </nav>

          <div className="p-4 border-t border-slate-800">
            <div className="flex items-center gap-3 px-4 py-3 mb-4">
              <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center">
                <UserIcon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{state.user?.name}</p>
                <p className="text-xs text-slate-400 truncate capitalize">{state.user?.role}</p>
              </div>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-3 w-full px-4 py-3 text-slate-400 hover:bg-slate-800 hover:text-white rounded-lg transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </div>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden" 
          onClick={toggle}
        />
      )}
    </>
  );
};

const Header = ({ toggleSidebar }: { toggleSidebar: () => void }) => {
  const { state } = useAuth();
  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-30">
      <button onClick={toggleSidebar} className="lg:hidden p-2 text-slate-600">
        <Menu className="w-6 h-6" />
      </button>
      <div className="flex-1 lg:flex-none">
        <h1 className="text-lg font-semibold text-slate-900 lg:hidden">Kaladi Coaching Center</h1>
      </div>
      <div className="flex items-center gap-4">
        <button className="p-2 text-slate-400 hover:text-slate-600 relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
        <div className="hidden sm:block text-right">
          <p className="text-sm font-medium text-slate-900">{state.user?.name}</p>
          <p className="text-xs text-slate-500 capitalize">{state.user?.role}</p>
        </div>
      </div>
    </header>
  );
};

const Card = ({ children, className, ...props }: { children: React.ReactNode; className?: string; [key: string]: any }) => (
  <div className={cn("bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden", className)} {...props}>
    {children}
  </div>
);

const StatCard = ({ title, value, icon: Icon, color, trend }: { title: string; value: string | number; icon: any; color: string; trend?: string }) => (
  <Card className="p-6">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
        {trend && (
          <p className={cn("text-xs mt-2 flex items-center gap-1", trend.startsWith('+') ? "text-emerald-600" : "text-red-600")}>
            <TrendingUp className="w-3 h-3" />
            {trend} from last month
          </p>
        )}
      </div>
      <div className={cn("p-3 rounded-xl", color)}>
        <Icon className="w-6 h-6" />
      </div>
    </div>
  </Card>
);

// --- Pages ---

const LoginPage = () => {
  const [email, setEmail] = useState('student@academy.com');
  const [password, setPassword] = useState('password123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      login(data.token, data.user);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <GraduationCap className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-slate-900">Welcome Back</h2>
          <p className="text-slate-500 mt-2">Sign in to manage your academy</p>
        </div>

        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="p-3 bg-red-50 border border-red-100 text-red-600 text-sm rounded-lg flex items-center gap-2">
                <XCircle className="w-4 h-4" />
                {error}
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                placeholder="••••••••"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 rounded-lg transition-colors disabled:opacity-50"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-100">
            <p className="text-xs text-center text-slate-400 uppercase tracking-widest font-semibold mb-4">Demo Accounts</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Admin', email: 'shahzadalilund@gmail.com' },
                { label: 'Teacher', email: 'teacher@academy.com' },
                { label: 'Student', email: 'student@academy.com' }
              ].map(acc => (
                <button
                  key={acc.label}
                  onClick={() => setEmail(acc.email)}
                  className="text-[10px] py-1 px-2 border border-slate-200 rounded hover:bg-slate-50 transition-colors"
                >
                  {acc.label}
                </button>
              ))}
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

const Dashboard = () => {
  const { state } = useAuth();
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [results, setResults] = useState<Result[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [att, res, ann] = await Promise.all([
          api.get('/api/attendance', state.token),
          api.get('/api/results', state.token),
          api.get('/api/announcements', state.token)
        ]);
        setAttendance(att);
        setResults(res);
        setAnnouncements(ann);
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
  }, [state.token]);

  const presentCount = attendance.filter(a => a.status === 'present').length;
  const attendanceRate = attendance.length ? Math.round((presentCount / attendance.length) * 100) : 0;
  
  const avgMarks = results.length 
    ? Math.round(results.reduce((acc, r) => acc + r.marks, 0) / results.length) 
    : 0;

  const chartData = [
    { name: 'Mon', attendance: 95 },
    { name: 'Tue', attendance: 88 },
    { name: 'Wed', attendance: 92 },
    { name: 'Thu', attendance: 90 },
    { name: 'Fri', attendance: 85 },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Welcome back, {state.user?.name}!</h2>
          <p className="text-slate-500">Here's what's happening in your academy today.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-slate-500">{format(new Date(), 'EEEE, MMMM do')}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Attendance Rate" 
          value={`${attendanceRate}%`} 
          icon={Calendar} 
          color="bg-indigo-50 text-indigo-600"
          trend="+2.4%"
        />
        <StatCard 
          title="Avg. Performance" 
          value={`${avgMarks}%`} 
          icon={TrendingUp} 
          color="bg-emerald-50 text-emerald-600"
          trend="+5.1%"
        />
        <StatCard 
          title="Active Tests" 
          value="3" 
          icon={ClipboardList} 
          color="bg-amber-50 text-amber-600"
        />
        <StatCard 
          title="New Notifications" 
          value={announcements.length} 
          icon={Bell} 
          color="bg-rose-50 text-rose-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-900">Attendance Overview</h3>
            <select className="text-sm border-none bg-slate-50 rounded-lg px-2 py-1 outline-none">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="attendance" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-bold text-slate-900 mb-6">Recent Announcements</h3>
          <div className="space-y-6">
            {announcements.slice(0, 3).map((ann) => (
              <div key={ann.id} className="flex gap-4">
                <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center shrink-0">
                  <Bell className="w-5 h-5 text-slate-600" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{ann.title}</h4>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-1">{ann.content}</p>
                  <span className="text-[10px] text-slate-400 mt-2 block uppercase tracking-wider font-bold">{ann.date}</span>
                </div>
              </div>
            ))}
            {announcements.length === 0 && (
              <p className="text-sm text-slate-500 text-center py-8">No new announcements</p>
            )}
            <Link to="/announcements" className="block text-center text-sm font-bold text-indigo-600 hover:text-indigo-700 mt-4">
              View All Announcements
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
};

const AttendancePage = () => {
  const { state } = useAuth();
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [students, setStudents] = useState<User[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [att, stds] = await Promise.all([
          api.get('/api/attendance', state.token),
          state.user?.role !== 'student' ? api.get('/api/students', state.token) : Promise.resolve([])
        ]);
        setAttendance(att);
        setStudents(stds);
        if (state.user?.role === 'student') setSelectedStudent(state.user.id);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [state.token, state.user]);

  const handleMarkAttendance = async (studentId: string, status: 'present' | 'absent') => {
    try {
      const date = new Date().toISOString().split('T')[0];
      const newEntry = await api.post('/api/attendance', { studentId, date, status }, state.token);
      setAttendance([...attendance, newEntry]);
    } catch (err) {
      console.error(err);
    }
  };

  const filteredAttendance = selectedStudent 
    ? attendance.filter(a => a.studentId === selectedStudent)
    : attendance;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Attendance Management</h2>
          <p className="text-slate-500">Track and manage daily attendance logs.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-6">
          {state.user?.role !== 'student' && (
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 mb-4">Select Student</h3>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {students.map(s => (
                  <button
                    key={s.id}
                    onClick={() => setSelectedStudent(s.id)}
                    className={cn(
                      "w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all",
                      selectedStudent === s.id 
                        ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
                        : "bg-slate-50 text-slate-600 hover:bg-slate-100"
                    )}
                  >
                    {s.name}
                  </button>
                ))}
              </div>
            </Card>
          )}

          {selectedStudent && state.user?.role !== 'student' && (
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 mb-4">Mark Today</h3>
              <div className="flex gap-2">
                <button 
                  onClick={() => handleMarkAttendance(selectedStudent, 'present')}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white py-2 rounded-lg font-bold transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Present
                </button>
                <button 
                  onClick={() => handleMarkAttendance(selectedStudent, 'absent')}
                  className="flex-1 bg-rose-500 hover:bg-rose-600 text-white py-2 rounded-lg font-bold transition-colors flex items-center justify-center gap-2"
                >
                  <XCircle className="w-4 h-4" />
                  Absent
                </button>
              </div>
            </Card>
          )}
        </div>

        <Card className="lg:col-span-3">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-900">Attendance Logs</h3>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                <span className="text-xs text-slate-500">Present</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-rose-500 rounded-full"></div>
                <span className="text-xs text-slate-500">Absent</span>
              </div>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50">
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Student</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAttendance.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-sm text-slate-900 font-medium">{format(parseISO(log.date), 'MMMM do, yyyy')}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                        log.status === 'present' ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                      )}>
                        {log.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {students.find(s => s.id === log.studentId)?.name || state.user?.name}
                    </td>
                  </tr>
                ))}
                {filteredAttendance.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-6 py-12 text-center text-slate-500">No logs found for this student.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* Monthly Summary for Parents/Students */}
      <div className="mt-12">
        <h3 className="text-xl font-bold text-slate-900 mb-6">Monthly Attendance Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(
            filteredAttendance.reduce((acc, curr) => {
              const month = format(parseISO(curr.date), 'MMMM yyyy');
              if (!acc[month]) acc[month] = { present: 0, total: 0 };
              acc[month].total++;
              if (curr.status === 'present') acc[month].present++;
              return acc;
            }, {} as Record<string, { present: number, total: number }>)
          ).map(([month, stats]: [string, any]) => (
            <Card key={month} className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-bold text-slate-900">{month}</h4>
                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full">
                  {Math.round((stats.present / stats.total) * 100)}% Attendance
                </span>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Days Present</span>
                  <span className="font-bold text-emerald-600">{stats.present}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Days Absent</span>
                  <span className="font-bold text-rose-600">{stats.total - stats.present}</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-indigo-600 h-full transition-all duration-500" 
                    style={{ width: `${(stats.present / stats.total) * 100}%` }}
                  ></div>
                </div>
              </div>
            </Card>
          ))}
          {filteredAttendance.length === 0 && (
            <div className="col-span-full py-12 text-center text-slate-500 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
              No monthly data available yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const AcademicPage = () => {
  const { state } = useAuth();
  const [tests, setTests] = useState<Test[]>([]);
  const [results, setResults] = useState<Result[]>([]);
  const [students, setStudents] = useState<User[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [t, r, s] = await Promise.all([
          api.get('/api/tests', state.token),
          api.get('/api/results', state.token),
          state.user?.role !== 'student' ? api.get('/api/students', state.token) : Promise.resolve([])
        ]);
        setTests(t);
        setResults(r);
        setStudents(s);
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
  }, [state.token, state.user]);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Academic Records</h2>
          <p className="text-slate-500">Tests, assignments, and performance tracking.</p>
        </div>
        {state.user?.role !== 'student' && (
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 transition-colors">
            <Plus className="w-5 h-5" />
            Add Test
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <div className="p-6 border-b border-slate-100">
            <h3 className="font-bold text-slate-900">Upcoming Tests</h3>
          </div>
          <div className="divide-y divide-slate-100">
            {tests.map(test => (
              <div key={test.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center">
                    <BookOpen className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{test.title}</h4>
                    <p className="text-sm text-slate-500">{format(parseISO(test.date), 'MMMM do, yyyy')}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Max Marks</p>
                  <p className="text-lg font-bold text-slate-900">{test.maxMarks}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="p-6 border-b border-slate-100">
            <h3 className="font-bold text-slate-900">Recent Results</h3>
          </div>
          <div className="divide-y divide-slate-100">
            {results.map(res => {
              const test = tests.find(t => t.id === res.testId);
              const student = students.find(s => s.id === res.studentId);
              return (
                <div key={res.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div>
                    <h4 className="font-bold text-slate-900">{test?.title}</h4>
                    <p className="text-sm text-slate-500">{student?.name || state.user?.name}</p>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-center">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Score</p>
                      <p className="text-lg font-bold text-slate-900">{res.marks}/{test?.maxMarks}</p>
                    </div>
                    <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center">
                      <span className="text-lg font-black text-emerald-600">{res.grade}</span>
                    </div>
                  </div>
                </div>
              );
            })}
            {results.length === 0 && (
              <p className="p-12 text-center text-slate-500">No results published yet.</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

const StudentsPage = () => {
  const { state } = useAuth();
  const [students, setStudents] = useState<User[]>([]);
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('password123');
  const [newClass, setNewClass] = useState('Grade 10');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; studentId: string | null }>({
    isOpen: false,
    studentId: null
  });

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const data = await api.get('/api/students', state.token);
        setStudents(data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchStudents();
  }, [state.token]);

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const newStudent = await api.post('/api/students', {
        name: newName,
        email: newEmail,
        password: newPassword,
        class: newClass
      }, state.token);
      setStudents([...students, newStudent]);
      setIsModalOpen(false);
      setNewName('');
      setNewEmail('');
      setNewPassword('password123');
    } catch (err: any) {
      setError('Failed to add student. Email might already be taken.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteStudent = async () => {
    if (!deleteModal.studentId) return;
    setLoading(true);
    try {
      await api.delete(`/api/students/${deleteModal.studentId}`, state.token);
      setStudents(students.filter(s => s.id !== deleteModal.studentId));
      setDeleteModal({ isOpen: false, studentId: null });
    } catch (err) {
      console.error(err);
      alert('Failed to delete student.');
    } finally {
      setLoading(false);
    }
  };

  const filtered = students.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase()) || 
    s.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Student Directory</h2>
          <p className="text-slate-500">Manage student profiles and academic info.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Add Student
        </button>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-slate-900">Add New Student</h3>
                <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <form onSubmit={handleAddStudent} className="p-6 space-y-4">
                {error && (
                  <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">
                    {error}
                  </div>
                )}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
                  <input
                    type="text"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Class</label>
                  <select
                    value={newClass}
                    onChange={(e) => setNewClass(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option>Grade 9</option>
                    <option>Grade 10</option>
                    <option>Grade 11</option>
                    <option>Grade 12</option>
                  </select>
                </div>
                <div className="pt-4 flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 px-4 py-2 border border-slate-200 text-slate-600 font-bold rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 px-4 py-2 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Adding...' : 'Add Student'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deleteModal.isOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 text-center"
            >
              <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Remove Student?</h3>
              <p className="text-slate-500 mb-6">
                Are you sure you want to remove this student? This will also delete their attendance and results. This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setDeleteModal({ isOpen: false, studentId: null })}
                  className="flex-1 px-4 py-2 border border-slate-200 text-slate-600 font-bold rounded-lg hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteStudent}
                  disabled={loading}
                  className="flex-1 px-4 py-2 bg-rose-500 text-white font-bold rounded-lg hover:bg-rose-600 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Deleting...' : 'Delete'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <Card>
        <div className="p-4 border-b border-slate-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search students by name or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50">
                <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Student</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Class</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Email</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((student) => (
                <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 font-bold">
                        {student.name.charAt(0)}
                      </div>
                      <span className="text-sm font-bold text-slate-900">{student.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">{student.class}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{student.email}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-bold uppercase tracking-wider rounded-full">Active</span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="text-indigo-600 hover:text-indigo-800 text-sm font-bold">Edit</button>
                      <button 
                        onClick={() => setDeleteModal({ isOpen: true, studentId: student.id })}
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Remove Student"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

const AnnouncementsPage = () => {
  const { state } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    const fetchAnn = async () => {
      try {
        const data = await api.get('/api/announcements', state.token);
        setAnnouncements(data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchAnn();
  }, [state.token]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const newAnn = await api.post('/api/announcements', { title, content }, state.token);
      setAnnouncements([newAnn, ...announcements]);
      setTitle('');
      setContent('');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Announcements</h2>
        <p className="text-slate-500">Stay updated with the latest news and alerts.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {state.user?.role !== 'student' && (
          <Card className="p-6 h-fit">
            <h3 className="font-bold text-slate-900 mb-4">Post Announcement</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="Announcement title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Content</label>
                <textarea
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none h-32 resize-none"
                  placeholder="Write your message here..."
                />
              </div>
              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg transition-colors"
              >
                Post Announcement
              </button>
            </form>
          </Card>
        )}

        <div className={cn("space-y-6", state.user?.role !== 'student' ? "lg:col-span-2" : "lg:col-span-3")}>
          {announcements.map((ann) => (
            <Card key={ann.id} className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center shrink-0">
                    <Bell className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900">{ann.title}</h4>
                    <p className="text-slate-600 mt-2 leading-relaxed">{ann.content}</p>
                    <div className="flex items-center gap-4 mt-4">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{format(parseISO(ann.date), 'MMMM do, yyyy')}</span>
                      <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                      <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Official</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
          {announcements.length === 0 && (
            <Card className="p-12 text-center text-slate-500">
              No announcements yet.
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

// --- Main App Layout ---

const AppLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { state } = useAuth();

  if (!state.isAuthenticated) return <Navigate to="/login" />;

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar isOpen={isSidebarOpen} toggle={() => setIsSidebarOpen(!isSidebarOpen)} />
      <div className="lg:ml-64 min-h-screen flex flex-col">
        <Header toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />
        <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={window.location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <Routes>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/attendance" element={<AttendancePage />} />
                <Route path="/academic" element={<AcademicPage />} />
                <Route path="/students" element={<StudentsPage />} />
                <Route path="/announcements" element={<AnnouncementsPage />} />
                <Route path="/" element={<Navigate to="/dashboard" />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

// --- Auth Provider ---

const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [state, setState] = useState<AuthState>(() => {
    const saved = localStorage.getItem('academy_auth');
    if (saved) {
      const { token, user } = JSON.parse(saved);
      return { token, user, isAuthenticated: true };
    }
    return { token: null, user: null, isAuthenticated: false };
  });

  const login = (token: string, user: User) => {
    localStorage.setItem('academy_auth', JSON.stringify({ token, user }));
    setState({ token, user, isAuthenticated: true });
  };

  const logout = () => {
    localStorage.removeItem('academy_auth');
    setState({ token: null, user: null, isAuthenticated: false });
  };

  return (
    <AuthContext.Provider value={{ state, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/*" element={<AppLayout />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

