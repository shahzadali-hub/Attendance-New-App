export type Role = 'admin' | 'teacher' | 'student';

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  class?: string;
}

export interface Attendance {
  id: string;
  studentId: string;
  date: string;
  status: 'present' | 'absent';
}

export interface Test {
  id: string;
  title: string;
  date: string;
  maxMarks: number;
}

export interface Result {
  id: string;
  testId: string;
  studentId: string;
  marks: number;
  grade: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}
