import express from 'express';
import cors from 'cors';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const JWT_SECRET = process.env.JWT_SECRET || 'academy-secret-key';

// Mock Database
const users = [
  { id: '1', email: 'shahzadalilund@gmail.com', password: '', role: 'admin', name: 'Admin User' },
  { id: '2', email: 'teacher@academy.com', password: '', role: 'teacher', name: 'John Doe' },
  { id: '3', email: 'student@academy.com', password: '', role: 'student', name: 'Jane Smith', class: 'Grade 10' },
];

// Default password for all mock users
const SALT = bcrypt.genSaltSync(10);
users.forEach(u => {
  if (u.role === 'admin') {
    u.password = bcrypt.hashSync('Kcc2606', SALT);
  } else {
    u.password = bcrypt.hashSync('password123', SALT);
  }
});

let attendance = [
  { id: '1', studentId: '3', date: '2026-03-20', status: 'present' },
  { id: '2', studentId: '3', date: '2026-03-21', status: 'absent' },
  { id: '3', studentId: '3', date: '2026-03-22', status: 'present' },
];

let tests = [
  { id: '1', title: 'Math Midterm', date: '2026-03-15', maxMarks: 100 },
  { id: '2', title: 'Science Quiz', date: '2026-03-25', maxMarks: 50 },
];

let results = [
  { id: '1', testId: '1', studentId: '3', marks: 85, grade: 'A' },
];

let announcements = [
  { id: '1', title: 'Spring Break', content: 'Spring break starts next week!', date: '2026-03-22' },
];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.sendStatus(403);
      req.user = user;
      next();
    });
  };

  // API Routes
  app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    const user = users.find(u => u.email === email);
    if (!user) return res.status(400).json({ message: 'User not found' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ message: 'Invalid password' });

    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
    const { password: _, ...userWithoutPassword } = user;
    res.json({ token, user: userWithoutPassword });
  });

  app.get('/api/me', authenticateToken, (req: any, res) => {
    const user = users.find(u => u.id === req.user.id);
    if (!user) return res.sendStatus(404);
    const { password: _, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Students
  app.get('/api/students', authenticateToken, (req: any, res) => {
    if (req.user.role === 'student') return res.sendStatus(403);
    res.json(users.filter(u => u.role === 'student'));
  });

  app.post('/api/students', authenticateToken, async (req: any, res) => {
    if (req.user.role === 'student') return res.sendStatus(403);
    const { name, email, password, class: studentClass } = req.body;
    
    if (users.find(u => u.email === email)) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(password || 'password123', 10);
    const newStudent = {
      id: String(users.length + 1),
      name,
      email,
      password: hashedPassword,
      role: 'student' as const,
      class: studentClass
    };
    
    users.push(newStudent);
    const { password: _, ...studentWithoutPassword } = newStudent;
    res.status(201).json(studentWithoutPassword);
  });

  app.delete('/api/students/:id', authenticateToken, (req: any, res) => {
    if (req.user.role === 'student') return res.sendStatus(403);
    const { id } = req.params;
    console.log(`Attempting to delete student with ID: ${id}`);
    const index = users.findIndex(u => u.id === id && u.role === 'student');
    if (index === -1) {
      console.log(`Student with ID: ${id} not found`);
      return res.status(404).json({ message: 'Student not found' });
    }
    
    users.splice(index, 1);
    // Also clean up their attendance and results
    attendance = attendance.filter(a => a.studentId !== id);
    results = results.filter(r => r.studentId !== id);
    
    console.log(`Successfully deleted student with ID: ${id}`);
    res.sendStatus(204);
  });

  // Attendance
  app.get('/api/attendance', authenticateToken, (req: any, res) => {
    const studentId = req.user.role === 'student' ? req.user.id : req.query.studentId;
    if (!studentId) return res.json(attendance);
    res.json(attendance.filter(a => a.studentId === studentId));
  });

  app.post('/api/attendance', authenticateToken, (req: any, res) => {
    if (req.user.role === 'student') return res.sendStatus(403);
    const { studentId, date, status } = req.body;
    const newEntry = { id: String(attendance.length + 1), studentId, date, status };
    attendance.push(newEntry);
    res.status(201).json(newEntry);
  });

  // Tests & Results
  app.get('/api/tests', authenticateToken, (req, res) => {
    res.json(tests);
  });

  app.get('/api/results', authenticateToken, (req: any, res) => {
    const studentId = req.user.role === 'student' ? req.user.id : req.query.studentId;
    if (!studentId) return res.json(results);
    res.json(results.filter(r => r.studentId === studentId));
  });

  app.post('/api/results', authenticateToken, (req: any, res) => {
    if (req.user.role === 'student') return res.sendStatus(403);
    const { testId, studentId, marks, grade } = req.body;
    const newResult = { id: String(results.length + 1), testId, studentId, marks, grade };
    results.push(newResult);
    res.status(201).json(newResult);
  });

  // Announcements
  app.get('/api/announcements', authenticateToken, (req, res) => {
    res.json(announcements);
  });

  app.post('/api/announcements', authenticateToken, (req: any, res) => {
    if (req.user.role === 'student') return res.sendStatus(403);
    const { title, content } = req.body;
    const newAnn = { id: String(announcements.length + 1), title, content, date: new Date().toISOString().split('T')[0] };
    announcements.push(newAnn);
    res.status(201).json(newAnn);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
